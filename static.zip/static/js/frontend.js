// frontend.js
const prescriptionSocket = new WebSocket('ws://localhost:8000/ws/prescription-notifications/');

prescriptionSocket.onmessage = function(e) {
    const data = JSON.parse(e.data);
    if (data.message) {
        alert(data.message);
    }
};
